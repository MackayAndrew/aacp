# AACP — Agent Action Compression Protocol

[![PyPI version](https://badge.fury.io/py/aacp.svg)](https://pypi.org/project/aacp/)
[![npm version](https://badge.fury.io/js/aacp-ts.svg)](https://www.npmjs.com/package/aacp-ts)

**Deterministic coordination for multi-agent LLM systems.**

> Status: `v1.3` · Benchmarks measured · MIT Licensed · IETF Internet-Draft filed

When agents coordinate in natural language, every instruction varies on every
run, costs tokens, and produces no reliable audit trail. AACP replaces that
with typed, validated, deterministic packets. Same input. Same output. Every time.

---

## Links

| | |
|---|---|
| **Spec and site** | [aacp.dev](https://aacp.dev) |
| **IETF Draft** | [draft-mackay-aacp-01](https://datatracker.ietf.org/doc/draft-mackay-aacp/) |
| **Python SDK** | [github.com/MackayAndrew/aacp](https://github.com/MackayAndrew/aacp) — `pip install aacp` |
| **TypeScript SDK** | [github.com/MackayAndrew/aacp-ts](https://github.com/MackayAndrew/aacp-ts) — `npm install aacp-ts` |
| **LangChain** | [github.com/MackayAndrew/aacp-langchain](https://github.com/MackayAndrew/aacp-langchain) |
| **CrewAI** | [github.com/MackayAndrew/aacp-crewai](https://github.com/MackayAndrew/aacp-crewai) |
| **Community rules** | [github.com/MackayAndrew/aacp-community-rules](https://github.com/MackayAndrew/aacp-community-rules) — 241 rules |
| **Registry API** | [registry.aacp.dev](https://registry.aacp.dev) |
| **VS Code extension** | [Dispatch AACP](https://marketplace.visualstudio.com/items?itemName=dispatch-aacp.dispatch-aacp) |
| **Packet builder** | [dispatch.aacp.dev](https://dispatch.aacp.dev) |
| **Working lab** | [github.com/MackayAndrew/aacp-lab](https://github.com/MackayAndrew/aacp-lab) |

---

## Install

```bash
# Python
pip install aacp

# TypeScript / JavaScript
npm install aacp-ts
```

---

## The problem

```
Natural language (56 tokens) — varies on every run, not auditable:
"Please retrieve the employee salary records for the period ending
March 2026. I need all active employees, their departments, cost
centres, base salary, any changes made this month, and pension
contribution rates. Return as JSON array."

AACP v1.1 (52 tokens) — identical every run, validated, auditable:
FETCH|HR|return:HR-Agent|p:1|aacp:1.1|res:emp_salary|period:2026-03|filter:status=active|fmt:json
```

---

## Measured results

Token counts from live API `usage_metadata`. 4-hop payroll workflow. May 2026.

| Hop | English | AACP | Claude | GPT-4o |
|---|---|---|---|---|
| fetch employees | 56 | 52 | -7.1% | -12.7% |
| fetch budgets | 57 | 47 | -17.5% | -16.0% |
| merge calculate | 65 | 43 | -33.8% | -31.6% |
| generate report | 62 | 43 | -30.6% | -33.3% |
| **TOTAL** | **240** | **185** | **-22.9%** | **-23.7%** |

Token reduction is a secondary benefit. The primary value is determinism
and auditability -- every packet is identical across runs and machine-readable
without post-processing.

---

## Framework integration results

Validated on real workflows. June 2026.

| Framework | Coordination calls eliminated | Total cost saving | Deterministic |
|---|---|---|---|
| LangChain (59 hops) | 59 → 0 | 18% | YES |
| CrewAI (4 hops) | 4 → 0 | 30% | YES |

- [aacp-langchain](https://github.com/MackayAndrew/aacp-langchain) — `pip install aacp-langchain`
- [aacp-crewai](https://github.com/MackayAndrew/aacp-crewai) — `pip install aacp-crewai`

---

## Quick start (Python)

```python
from aacp.encoders.workflows.payroll import PayrollEncoder

enc = PayrollEncoder()
pkt = enc.fetch_employees(period="2026-03")
print(pkt.packet)
# FETCH|HR|return:HR-Agent|p:1|aacp:1.1|res:emp_salary|period:2026-03|filter:status=active|fmt:json
print(f"Cost: ${pkt.api_cost_usd:.2f}")  # $0.00

# Novel instructions — fallback to LLM, logged to registry
from aacp.encoders.fallback import FallbackEncoder
enc = FallbackEncoder()
pkt = enc.encode_english(
    english="Cross-reference contractors against the approved vendor list.",
    domain="FIN",
    return_agent="FIN-Agent"
)
# First call: LLM once, ~$0.002
# Every subsequent identical call: $0.00 from registry cache
```

## Quick start (TypeScript)

```typescript
import { PayrollEncoder, AACPValidator, AACPDecoder } from "aacp-ts";

const enc = new PayrollEncoder();
const pkt = enc.fetchEmployees("2026-03");
console.log(pkt.packet);
console.log(pkt.apiCostUsd); // 0
```

---

## Packet format

```
TASK|DOM|return:AGENT|p:PRIORITY|aacp:VERSION|key:value|key:value...
```

**Valid TASK:** `FETCH` `PROC` `FLAG` `RESOLVE` `LOG` `SEND` `BUILD` `MERGE` `CALC` `REPORT` `ACK` `SYNC`

**Valid DOM:** `HR` `FIN` `SALES` `LEGAL` `IT` `CS` `MKT`

---

## Workflow encoders

8 encoders across 6 domains, each grounded in a documented real-world platform.
Available in Python and TypeScript. Zero LLM cost.

| Encoder | Domain | Hops | Real-world basis |
|---|---|---|---|
| `PayrollEncoder` | HR | 6 | HMRC PAYE |
| `ITEncoder` | IT | 5 | Microsoft Entra ID |
| `InvoiceEncoder` | FIN | 3 | AP three-way match |
| `ContractEncoder` | LEGAL | 2-3 | NDA/MSA review |
| `SalesEncoder` | SALES | 5 | Salesforce Agentforce 2026 |
| `JMLEncoder` | HR+IT | 6 | ConductorOne, Lumos, CloudEagle |
| `CSResolutionEncoder` | CS | 5 | Zendesk Resolution Platform 2026 |
| `MonthEndEncoder` | FIN | 6 | NetSuite Autonomous Close 2026 |

See [docs/encoder-reference.md](docs/encoder-reference.md) for citations.

---

## Three-tier fallback encoder

```
Tier 1 — Hash cache:     exact match → $0.00
Tier 2 — Pattern match:  registry or builtin → $0.00
Tier 3 — LLM fallback:   novel → LLM once → logged → ~$0.002
                          next call → Tier 1 → $0.00
```

Amortisation benchmark: 6 LLM calls across 240 encoding operations. 91.6% saving.

---

## Community rule library

241 pre-validated rules across 7 domains. MIT licensed. Zero API cost.

```python
# Coming in v1.4:
from aacp import RuleRegistry
registry = RuleRegistry.from_community()
registry = RuleRegistry.from_hosted()  # registry.aacp.dev
```

Browse: [github.com/MackayAndrew/aacp-community-rules](https://github.com/MackayAndrew/aacp-community-rules)
API: [registry.aacp.dev](https://registry.aacp.dev)

---

## Multi-model lab results (Lab v3)

5 workflows, 4 models, all passing. June 2026.

| Model | Cost | Tokens in | Latency | Pass |
|---|---|---|---|---|
| gpt-4.1-mini | $0.0190 | 40,585 | 160s | ✓ 5/5 |
| gpt-4.1 | $0.0984 | 41,005 | 124s | ✓ 5/5 |
| claude-sonnet-4-5 | $0.2237 | 53,127 | 423s | ✓ 5/5 |
| gpt-4o | $0.2408 | 40,459 | 101s | ✓ 5/5 |

Lab: [github.com/MackayAndrew/aacp-lab](https://github.com/MackayAndrew/aacp-lab)

---

## Relationship to existing protocols

| Protocol | Layer | AACP relationship |
|---|---|---|
| MCP (Anthropic/AAIF) | Tool access | AACP inside MCP payloads |
| A2A (Google/AAIF) | Agent routing | AACP structures A2A message content |
| Existing APIs / JSON | Service comms | AACP for the LLM agent coordination layer on top |

AACP fills the coordination content layer -- the layer between routing
(A2A, MCP) and task execution (the LLM doing actual work).

---

## Roadmap

| Version | Status | Focus |
|---|---|---|
| v1.0 | Released | Pipe-delimited format, rule-based encoders |
| v1.1 | Released | Validated benchmarks — -22.9% Claude, -23.7% GPT-4o |
| v1.2 | Released | Fallback loop closed, PyPI + npm, IETF draft-01 |
| v1.3 | Released | 8 encoders, TypeScript SDK, VS Code extension, community rules (241), lab v3, amortisation benchmark, LangChain + CrewAI integrations |
| v1.4 | Planned | RuleRegistry (from_community, from_hosted), QBR encoder |
| v2.0 | Planned | IETF draft-02, AAIF submission |

---

## Licence

MIT — free to use, implement, extend, and fork.

*AACP is an independent protocol proposal. Not affiliated with
Anthropic, Google, IBM, or the Linux Foundation, though designed
to complement MCP, A2A, and ACP.*
